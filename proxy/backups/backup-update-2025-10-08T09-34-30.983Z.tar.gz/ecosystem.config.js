// This file is no longer used and can be safely deleted.
// Please follow the updated instructions in README.md to start the servers
// using individual `pm2 start` commands.
