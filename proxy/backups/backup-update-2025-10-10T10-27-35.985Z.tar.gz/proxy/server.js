const express = require('express');
const path = require('path');
const fs = require('fs');
const { exec } = require('child_process');
const sqlite3 = require('@vscode/sqlite3');
const { open } = require('sqlite');
const esbuild = require('esbuild');
const archiver = require('archiver');
const fsExtra = require('fs-extra');
const tar = require('tar');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const os = require('os');
const fsPromises = require('fs').promises;

const app = express();
const PORT = 3001;
const DB_PATH = path.join(__dirname, 'panel.db');
const BACKUP_DIR = path.join(__dirname, 'backups');
const API_BACKEND_FILE = path.join(__dirname, '..', 'api-backend', 'server.js');
const SECRET_KEY = process.env.JWT_SECRET || 'a-very-weak-secret-key-for-dev-only';

app.use(express.json({ limit: '5mb' }));
app.use(express.text({ limit: '5mb' })); // For AI fixer

// Ensure backup directory exists
fs.mkdirSync(BACKUP_DIR, { recursive: true });

let db;

// --- Database Initialization and Migrations ---
async function initDb() {
    try {
        db = await open({
            filename: DB_PATH,
            driver: sqlite3.Database
        });
        console.log('Connected to the panel database.');

        // Enable foreign keys
        await db.exec('PRAGMA foreign_keys = ON;');

        // Migrations
        await db.exec('PRAGMA user_version;');
        let { user_version } = await db.get('PRAGMA user_version;');
        console.log(`Current DB version: ${user_version}`);

        if (user_version < 1) {
            console.log('Applying migration v1...');
            await db.exec(`
                CREATE TABLE IF NOT EXISTS routers (
                    id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    host TEXT NOT NULL,
                    user TEXT NOT NULL,
                    password TEXT,
                    port INTEGER NOT NULL
                );
                CREATE TABLE IF NOT EXISTS panel_settings (key TEXT PRIMARY KEY, value TEXT);
                CREATE TABLE IF NOT EXISTS company_settings (key TEXT PRIMARY KEY, value TEXT);
                CREATE TABLE IF NOT EXISTS billing_plans (id TEXT PRIMARY KEY, name TEXT, price REAL, cycle TEXT, pppoeProfile TEXT, description TEXT);
                CREATE TABLE IF NOT EXISTS sales_records (id TEXT PRIMARY KEY, date TEXT, clientName TEXT, planName TEXT, planPrice REAL, discountAmount REAL, finalAmount REAL, routerName TEXT);
                CREATE TABLE IF NOT EXISTS customers (id TEXT PRIMARY KEY, username TEXT NOT NULL, routerId TEXT NOT NULL, fullName TEXT, address TEXT, contactNumber TEXT, email TEXT);
                CREATE TABLE IF NOT EXISTS inventory (id TEXT PRIMARY KEY, name TEXT, quantity INTEGER, price REAL, serialNumber TEXT, dateAdded TEXT);
            `);
            await db.exec('PRAGMA user_version = 1;');
            user_version = 1;
        }

        if (user_version < 2) {
            console.log('Applying migration v2...');
            // Make migration idempotent: check if column exists before adding
            const billingCols = await db.all("PRAGMA table_info(billing_plans);");
            if (!billingCols.some(c => c.name === 'currency')) {
                await db.exec('ALTER TABLE billing_plans ADD COLUMN currency TEXT;');
            }
            const salesCols = await db.all("PRAGMA table_info(sales_records);");
            if (!salesCols.some(c => c.name === 'currency')) {
                await db.exec('ALTER TABLE sales_records ADD COLUMN currency TEXT;');
            }
            await db.exec('PRAGMA user_version = 2;');
            user_version = 2;
        }
        
        if (user_version < 3) {
             console.log('Applying migration v3...');
            const salesCols = await db.all("PRAGMA table_info(sales_records);");
            if (!salesCols.some(c => c.name === 'clientAddress')) await db.exec('ALTER TABLE sales_records ADD COLUMN clientAddress TEXT;');
            if (!salesCols.some(c => c.name === 'clientContact')) await db.exec('ALTER TABLE sales_records ADD COLUMN clientContact TEXT;');
            if (!salesCols.some(c => c.name === 'clientEmail')) await db.exec('ALTER TABLE sales_records ADD COLUMN clientEmail TEXT;');
            await db.exec('PRAGMA user_version = 3;');
            user_version = 3;
        }
        
        if (user_version < 4) {
            console.log('Applying migration v4 (Settings Table Schema Fix)...');
            // This robustly fixes the settings tables if they have the wrong schema
            const fixSettingsTable = async (tableName) => {
                 const cols = await db.all(`PRAGMA table_info(${tableName});`);
                 // If there's no 'key' column, the schema is wrong.
                 if (!cols.some(c => c.name === 'key')) {
                     console.log(`Rebuilding malformed table: ${tableName}`);
                     await db.exec(`ALTER TABLE ${tableName} RENAME TO ${tableName}_old;`);
                     await db.exec(`CREATE TABLE ${tableName} (key TEXT PRIMARY KEY, value TEXT);`);
                     // Attempt to copy old data if possible (best effort)
                     try {
                         // This assumes old tables had single-row data that can be converted
                         const oldData = await db.get(`SELECT * FROM ${tableName}_old LIMIT 1;`);
                         if (oldData) {
                            for (const [key, value] of Object.entries(oldData)) {
                                if (value !== null && value !== undefined) {
                                     await db.run(`INSERT OR REPLACE INTO ${tableName} (key, value) VALUES (?, ?);`, key, JSON.stringify(value));
                                }
                            }
                         }
                     } catch(e) {
                         console.error(`Could not migrate data from ${tableName}_old:`, e.message);
                     }
                     await db.exec(`DROP TABLE ${tableName}_old;`);
                 }
            };
            await fixSettingsTable('company_settings');
            await fixSettingsTable('panel_settings');
            await db.exec('PRAGMA user_version = 4;');
            user_version = 4;
        }
        
        if (user_version < 5) {
            console.log('Applying migration v5 (Force-fix settings table schemas)...');
            const forceFixSettingsTable = async (tableName) => {
                try {
                    const cols = await db.all(`PRAGMA table_info(${tableName});`);
                    // If the schema is wrong (doesn't have a 'key' column), we rebuild it.
                    if (!cols.some(c => c.name === 'key')) {
                        console.log(`Force-rebuilding malformed table: ${tableName}`);
                        await db.exec(`DROP TABLE IF EXISTS ${tableName};`);
                        await db.exec(`CREATE TABLE ${tableName} (key TEXT PRIMARY KEY, value TEXT);`);
                        console.log(`Table ${tableName} has been rebuilt successfully.`);
                    }
                } catch (e) {
                    // This might fail if the table doesn't exist at all, so we create it.
                    if (e.message.includes('no such table')) {
                        console.log(`Table ${tableName} does not exist, creating fresh.`);
                        await db.exec(`CREATE TABLE IF NOT EXISTS ${tableName} (key TEXT PRIMARY KEY, value TEXT);`);
                    } else {
                        // Re-throw other errors
                        console.error(`Error during migration for table ${tableName}:`, e);
                        throw e;
                    }
                }
            };
            await forceFixSettingsTable('company_settings');
            await forceFixSettingsTable('panel_settings');
            await db.exec('PRAGMA user_version = 5;');
            user_version = 5;
        }

        if (user_version < 6) {
            console.log('Applying migration v6 (Add expenses table)...');
            await db.exec(`
                CREATE TABLE IF NOT EXISTS expenses (
                    id TEXT PRIMARY KEY,
                    date TEXT NOT NULL,
                    category TEXT NOT NULL,
                    description TEXT,
                    amount REAL NOT NULL
                );
            `);
            await db.exec('PRAGMA user_version = 6;');
            user_version = 6;
        }
        
        if (user_version < 7) {
            console.log('Applying migration v7 (Add routerId to sales and billing)...');
            
            const salesCols = await db.all("PRAGMA table_info(sales_records);");
            if (!salesCols.some(c => c.name === 'routerId')) {
                await db.exec('ALTER TABLE sales_records ADD COLUMN routerId TEXT;');
            }

            const billingCols = await db.all("PRAGMA table_info(billing_plans);");
            if (!billingCols.some(c => c.name === 'routerId')) {
                await db.exec('ALTER TABLE billing_plans ADD COLUMN routerId TEXT;');
            }
            
            await db.exec('PRAGMA user_version = 7;');
            user_version = 7;
        }
        
        if (user_version < 8) {
            console.log('Applying migration v8 (Verifying routerId columns)...');
            
            const salesCols = await db.all("PRAGMA table_info(sales_records);");
            if (!salesCols.some(c => c.name === 'routerId')) {
                console.log('Adding missing routerId column to sales_records.');
                await db.exec('ALTER TABLE sales_records ADD COLUMN routerId TEXT;');
            }

            const billingCols = await db.all("PRAGMA table_info(billing_plans);");
            if (!billingCols.some(c => c.name === 'routerId')) {
                console.log('Adding missing routerId column to billing_plans.');
                await db.exec('ALTER TABLE billing_plans ADD COLUMN routerId TEXT;');
            }
            
            await db.exec('PRAGMA user_version = 8;');
            user_version = 8;
        }

        if (user_version < 9) {
            console.log('Applying migration v9 (Add users table for auth)...');
            await db.exec(`
                CREATE TABLE IF NOT EXISTS users (
                    id TEXT PRIMARY KEY,
                    username TEXT UNIQUE NOT NULL,
                    password TEXT NOT NULL
                );
            `);
            await db.exec('PRAGMA user_version = 9;');
            user_version = 9;
        }
        
        if (user_version < 10) {
            console.log('Applying migration v10 (Add user security questions)...');
            await db.exec(`
                CREATE TABLE IF NOT EXISTS user_security_questions (
                    id TEXT PRIMARY KEY,
                    user_id TEXT NOT NULL,
                    question TEXT NOT NULL,
                    answer TEXT NOT NULL,
                    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
                );
            `);
            await db.exec('PRAGMA user_version = 10;');
            user_version = 10;
        }


    } catch (err) {
        console.error('Failed to initialize database:', err);
        process.exit(1);
    }
}

// --- Authentication ---
const authRouter = express.Router();

authRouter.get('/has-users', async (req, res) => {
    try {
        const row = await db.get("SELECT COUNT(*) as count FROM users");
        res.json({ hasUsers: row.count > 0 });
    } catch (e) {
        res.status(500).json({ message: e.message });
    }
});

authRouter.post('/register', async (req, res) => {
    const { username, password, securityQuestions } = req.body;
    if (!username || !password || !securityQuestions || securityQuestions.length < 3) {
        return res.status(400).json({ message: 'Username, password, and three security questions are required.' });
    }
    
    try {
        const row = await db.get("SELECT COUNT(*) as count FROM users");
        if (row.count > 0) {
            return res.status(403).json({ message: 'Registration is only allowed for the first administrator account.' });
        }

        await db.exec('BEGIN TRANSACTION;');

        const hashedPassword = await bcrypt.hash(password, 10);
        const userId = `user_${Date.now()}`;
        const user = { id: userId, username };

        await db.run('INSERT INTO users (id, username, password) VALUES (?, ?, ?)', user.id, user.username, hashedPassword);

        for (const qa of securityQuestions) {
            if (qa.question && qa.answer) {
                const normalizedAnswer = qa.answer.trim().toLowerCase();
                const hashedAnswer = await bcrypt.hash(normalizedAnswer, 10);
                await db.run(
                    'INSERT INTO user_security_questions (id, user_id, question, answer) VALUES (?, ?, ?, ?)',
                    `sq_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`,
                    userId,
                    qa.question,
                    hashedAnswer
                );
            }
        }
        
        await db.exec('COMMIT;');
        
        const token = jwt.sign({ id: user.id, username: user.username }, SECRET_KEY, { expiresIn: '7d' });
        res.status(201).json({ token, user });

    } catch (e) {
        await db.exec('ROLLBACK;');
        if (e.message.includes('UNIQUE constraint failed')) {
            return res.status(409).json({ message: 'Username already exists.' });
        }
        res.status(500).json({ message: e.message });
    }
});

authRouter.post('/login', async (req, res) => {
    const { username, password } = req.body;
    if (!username || !password) {
        return res.status(400).json({ message: 'Username and password are required.' });
    }
    try {
        const user = await db.get('SELECT * FROM users WHERE username = ?', username);
        if (!user) {
            return res.status(401).json({ message: 'Invalid username or password.' });
        }
        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(401).json({ message: 'Invalid username or password.' });
        }

        const token = jwt.sign({ id: user.id, username: user.username }, SECRET_KEY, { expiresIn: '7d' });
        res.json({ token, user: { id: user.id, username: user.username } });

    } catch (e) {
        res.status(500).json({ message: e.message });
    }
});

authRouter.get('/security-questions/:username', async (req, res) => {
    try {
        const { username } = req.params;
        const user = await db.get('SELECT id FROM users WHERE username = ?', username);
        if (!user) {
            // To prevent username enumeration, we send back an empty array even if the user doesn't exist.
            // The frontend should check for an empty array and show a generic error.
            return res.json({ questions: [] });
        }
        const questions = await db.all('SELECT question FROM user_security_questions WHERE user_id = ? ORDER BY id', user.id);
        res.json({ questions: questions.map(q => q.question) });
    } catch (e) {
        res.status(500).json({ message: e.message });
    }
});

authRouter.post('/reset-password', async (req, res) => {
    const { username, answers, newPassword } = req.body;
    if (!username || !answers || !newPassword || !Array.isArray(answers) || answers.length === 0) {
        return res.status(400).json({ message: 'Username, answers, and new password are required.' });
    }
    try {
        const user = await db.get('SELECT id FROM users WHERE username = ?', username);
        if (!user) {
            return res.status(401).json({ message: 'Invalid username or answers.' });
        }

        const storedAnswers = await db.all('SELECT answer FROM user_security_questions WHERE user_id = ? ORDER BY id', user.id);

        if (answers.length !== storedAnswers.length) {
            return res.status(401).json({ message: 'Invalid username or answers.' });
        }

        let allAnswersMatch = true;
        for (let i = 0; i < answers.length; i++) {
            const normalizedAnswer = (answers[i] || '').trim().toLowerCase();
            const isMatch = await bcrypt.compare(normalizedAnswer, storedAnswers[i].answer);
            if (!isMatch) {
                allAnswersMatch = false;
                break;
            }
        }

        if (!allAnswersMatch) {
            return res.status(401).json({ message: 'Invalid username or answers.' });
        }

        const hashedNewPassword = await bcrypt.hash(newPassword, 10);
        await db.run('UPDATE users SET password = ? WHERE id = ?', hashedNewPassword, user.id);
        
        res.json({ message: 'Password has been reset successfully.' });

    } catch (e) {
        res.status(500).json({ message: e.message });
    }
});

const protect = (req, res, next) => {
    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith('Bearer ')) {
        const token = authHeader.split(' ')[1];
        jwt.verify(token, SECRET_KEY, (err, user) => {
            if (err) {
                return res.status(401).json({ message: 'Invalid or expired token.' });
            }
            req.user = user;
            next();
        });
    } else {
        res.status(401).json({ message: 'Not authenticated, no token provided.' });
    }
};

authRouter.post('/reset-all', protect, async (req, res) => {
    try {
        // Since user_security_questions has ON DELETE CASCADE, deleting from users is sufficient.
        await db.exec('DELETE FROM users');
        res.json({ message: 'All user credentials have been reset.' });
    } catch (e) {
        res.status(500).json({ message: `Failed to reset credentials: ${e.message}` });
    }
});

authRouter.get('/status', protect, (req, res) => {
    res.json(req.user);
});

authRouter.post('/logout', (req, res) => {
    // In a stateless JWT setup, logout is mainly handled client-side by deleting the token.
    // This endpoint is here for completeness and could be used for token blacklisting in a more complex setup.
    res.status(200).json({ message: 'Logged out successfully.' });
});

app.use('/api/auth', authRouter);

// --- ESBuild Middleware for TS/TSX ---
app.use(async (req, res, next) => {
    if (req.path.endsWith('.tsx') || req.path.endsWith('.ts')) {
        try {
            const filePath = path.join(__dirname, '..', req.path);
            const source = await fs.promises.readFile(filePath, 'utf8');
            const result = await esbuild.transform(source, {
                loader: req.path.endsWith('.tsx') ? 'tsx' : 'ts',
                format: 'esm'
            });
            res.type('application/javascript').send(result.code);
        } catch (error) {
            console.error(`esbuild error: ${error}`);
            res.status(500).send('Error compiling TypeScript file.');
        }
    } else {
        next();
    }
});

// --- API Endpoints ---

// Host Status
app.get('/api/host-status', protect, (req, res) => {
    const getCpuUsage = () => new Promise(resolve => {
        exec("top -bn1 | grep 'Cpu(s)' | sed 's/.*, *\\([0-9.]*\\)%* id.*/\\1/' | awk '{print 100 - $1}'", (err, stdout) => {
            resolve(parseFloat(stdout.trim()) || 0);
        });
    });

    const getMemoryUsage = () => new Promise(resolve => {
        exec("free -m | awk 'NR==2{printf \"{\\\"total\\\":\\\"%sMB\\\", \\\"used\\\":\\\"%sMB\\\", \\\"free\\\":\\\"%sMB\\\", \\\"percent\\\":%.2f}\", $2, $3, $4, $3*100/$2 }'", (err, stdout) => {
             resolve(JSON.parse(stdout));
        });
    });

    const getDiskUsage = () => new Promise(resolve => {
         exec("df -h / | awk 'NR==2{printf \"{\\\"total\\\":\\\"%s\\\", \\\"used\\\":\\\"%s\\\", \\\"free\\\":\\\"%s\\\", \\\"percent\\\":%d}\", $2, $3, $4, $5}'", (err, stdout) => {
            resolve(JSON.parse(stdout));
        });
    });
    
    Promise.all([getCpuUsage(), getMemoryUsage(), getDiskUsage()]).then(([cpu, mem, disk]) => {
        res.json({ cpuUsage: cpu, memory: mem, disk });
    }).catch(err => res.status(500).json({ message: err.message }));
});

// Panel NTP Status
app.get('/api/system/host-ntp-status', protect, (req, res) => {
    exec("timedatectl status | grep 'NTP service:'", (err, stdout, stderr) => {
        if (err) {
            console.error("Failed to get NTP status:", stderr);
            return res.status(500).json({ message: "Could not retrieve NTP status from host. 'timedatectl' may not be available." });
        }
        const enabled = stdout.includes('active');
        res.json({ enabled });
    });
});

app.post('/api/system/host-ntp/toggle', protect, (req, res) => {
    const { enabled } = req.body;
    if (typeof enabled !== 'boolean') {
        return res.status(400).json({ message: 'A boolean "enabled" property is required.' });
    }
    exec(`sudo timedatectl set-ntp ${enabled}`, (err, stdout, stderr) => {
        if (err) {
            console.error("Failed to toggle NTP:", stderr);
            return res.status(500).json({ message: `Failed to set NTP status. Make sure the panel's user has passwordless sudo rights for 'timedatectl'. Error: ${stderr}` });
        }
        res.json({ message: `NTP service has been ${enabled ? 'enabled' : 'disabled'}.` });
    });
});


// Generic Database API
const tableMap = {
    'sales': 'sales_records',
    'billing-plans': 'billing_plans',
    'company-settings': 'company_settings',
    'panel-settings': 'panel_settings'
};

const dbRouter = express.Router();

dbRouter.use('/:table', (req, res, next) => {
    const originalTable = req.params.table;
    req.tableName = tableMap[originalTable] || originalTable;
    next();
});

dbRouter.get('/:table', async (req, res) => {
    try {
        const { routerId } = req.query;
        let query = `SELECT * FROM ${req.tableName}`;
        const params = [];

        const cols = await db.all(`PRAGMA table_info(${req.tableName});`);
        const hasRouterId = cols.some(c => c.name === 'routerId');

        if (hasRouterId) {
            if (routerId) {
                query += ' WHERE routerId = ?';
                params.push(routerId);
            } else {
                // If the table is router-specific but no routerId is provided, return an empty array.
                return res.json([]);
            }
        }
        
        const items = await db.all(query, params);
        res.json(items);
    } catch (e) { res.status(500).json({ message: e.message }); }
});
// ... more generic routes
dbRouter.post('/:table', async (req, res) => {
    try {
        const columns = Object.keys(req.body).join(', ');
        const placeholders = Object.keys(req.body).map(() => '?').join(', ');
        const values = Object.values(req.body);
        await db.run(`INSERT INTO ${req.tableName} (${columns}) VALUES (${placeholders})`, values);
        res.status(201).json({ message: 'Created' });
    } catch (e) { res.status(500).json({ message: e.message }); }
});

dbRouter.patch('/:table/:id', async (req, res) => {
     try {
        const updates = Object.keys(req.body).map(key => `${key} = ?`).join(', ');
        const values = [...Object.values(req.body), req.params.id];
        await db.run(`UPDATE ${req.tableName} SET ${updates} WHERE id = ?`, values);
        res.json({ message: 'Updated' });
    } catch (e) { res.status(500).json({ message: e.message }); }
});
dbRouter.delete('/:table/:id', async (req, res) => {
    try {
        await db.run(`DELETE FROM ${req.tableName} WHERE id = ?`, req.params.id);
        res.status(204).send();
    } catch (e) { res.status(500).json({ message: e.message }); }
});
dbRouter.post('/:table/clear-all', async (req, res) => {
    try {
        const { routerId } = req.body;
        let query = `DELETE FROM ${req.tableName}`;
        const params = [];

        const cols = await db.all(`PRAGMA table_info(${req.tableName});`);
        const hasRouterId = cols.some(c => c.name === 'routerId');

        if (hasRouterId) {
            if (routerId) {
                 query += ' WHERE routerId = ?';
                 params.push(routerId);
            } else {
                // If routerId is required but not provided, do nothing and return error
                return res.status(400).json({ message: 'routerId is required to clear this table.' });
            }
        }
        
        await db.run(query, params);
        res.status(204).send();
    } catch(e) { res.status(500).json({ message: e.message }); }
});

// --- Database Routes ---

// Special handlers for key-value settings tables
const createSettingsHandler = (tableName) => async (req, res) => {
    try {
        const rows = await db.all(`SELECT * FROM ${tableName}`);
        const settings = rows.reduce((acc, row) => {
            try { acc[row.key] = JSON.parse(row.value); }
            catch { acc[row.key] = row.value; }
            return acc;
        }, {});
        res.json(settings);
    } catch (e) { res.status(500).json({ message: e.message }); }
};
const createSettingsSaver = (tableName) => async (req, res) => {
    try {
        await db.exec('BEGIN TRANSACTION;');
        for (const [key, value] of Object.entries(req.body)) {
            await db.run(`INSERT OR REPLACE INTO ${tableName} (key, value) VALUES (?, ?);`, key, JSON.stringify(value));
        }
        await db.exec('COMMIT;');
        res.json({ message: 'Settings saved.' });
    } catch (e) {
        await db.exec('ROLLBACK;');
        res.status(500).json({ message: e.message });
    }
};

// FIX: Define specific routes BEFORE the generic `dbRouter` to ensure they are matched first.
app.get('/api/db/panel-settings', protect, createSettingsHandler('panel_settings'));
app.post('/api/db/panel-settings', protect, createSettingsSaver('panel_settings'));
app.get('/api/db/company-settings', protect, createSettingsHandler('company_settings'));
app.post('/api/db/company-settings', protect, createSettingsSaver('company_settings'));

// All other /api/db routes will be handled by the generic router.
app.use('/api/db', protect, dbRouter);


// --- ZeroTier CLI ---
const ztCli = (command) => new Promise((resolve, reject) => {
    exec(`sudo zerotier-cli -j ${command}`, (error, stdout, stderr) => {
        if (error) {
            const errMsg = stderr || error.message;
            if (errMsg.includes("sudo: a terminal is required") || errMsg.includes("sudo: a password is required")) {
                return reject({ status: 403, code: 'SUDO_PASSWORD_REQUIRED', message: 'Passwordless sudo is not configured correctly for the panel user.' });
            }
            if (stderr.includes("zerotier-cli: missing authentication token")) {
                return reject({ status: 500, code: 'ZEROTIER_SERVICE_DOWN', message: 'ZeroTier service is not running or token is missing.' });
            }
            if (error.message.includes('No such file or directory')) {
                return reject({ status: 404, code: 'ZEROTIER_NOT_INSTALLED', message: 'zerotier-cli not found.' });
            }
            return reject({ status: 500, message: errMsg });
        }
        try {
            resolve(JSON.parse(stdout));
        } catch (parseError) {
            reject({ status: 500, message: `Failed to parse zerotier-cli output: ${stdout}` });
        }
    });
});

app.get('/api/zt/status', protect, async (req, res) => {
    try {
        const [info, networks] = await Promise.all([ztCli('info'), ztCli('listnetworks')]);
        res.json({ info, networks });
    } catch (err) {
        res.status(err.status || 500).json({ message: err.message, code: err.code });
    }
});
// ... other ZT routes
app.post('/api/zt/join', protect, async (req, res) => {
    try {
        const { networkId } = req.body;
        await ztCli(`join ${networkId}`);
        res.json({ message: 'Join command sent.' });
    } catch(err) { res.status(err.status || 500).json({ message: err.message }); }
});
app.post('/api/zt/leave', protect, async (req, res) => {
    try {
        const { networkId } = req.body;
        await ztCli(`leave ${networkId}`);
        res.json({ message: 'Leave command sent.' });
    } catch(err) { res.status(err.status || 500).json({ message: err.message }); }
});
app.post('/api/zt/set', protect, async (req, res) => {
    try {
        const { networkId, setting, value } = req.body;
        await ztCli(`set ${networkId} ${setting}=${value}`);
        res.json({ message: 'Setting updated.' });
    } catch(err) { res.status(err.status || 500).json({ message: err.message }); }
});

// ZT Installer
app.get('/api/zt/install', protect, (req, res) => {
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    
    const child = exec('curl -s https://install.zerotier.com | sudo bash');
    const send = (data) => res.write(`data: ${JSON.stringify(data)}\n\n`);

    child.stdout.on('data', log => send({ log }));
    child.stderr.on('data', log => send({ log }));
    child.on('close', code => {
        if (code === 0) {
            send({ status: 'success' });
        } else {
            send({ status: 'error', message: 'Installation script failed.' });
        }
        send({ status: 'finished' });
        res.end();
    });
});

// --- Host Router Endpoints ---
const runSudo = (command) => new Promise((resolve, reject) => {
    exec(`sudo ${command}`, (err, stdout, stderr) => {
        if (err) {
            console.error(`Sudo error for command "${command}": ${stderr}`);
            if (stderr.includes("sudo: a terminal is required") || stderr.includes("sudo: a password is required")) {
                return reject(new Error('Passwordless sudo is not configured correctly for the panel user.'));
            }
            return reject(new Error(stderr || err.message));
        }
        resolve(stdout);
    });
});

app.get('/api/host/network-config', protect, async (req, res) => {
    try {
        // 1. Get interfaces
        const rawIfaces = os.networkInterfaces();
        const interfaces = Object.entries(rawIfaces).map(([name, details]) => {
            const ipv4 = details.find(d => d.family === 'IPv4' && !d.internal);
            // Find the mac from any of the interface's addresses, as it can be on IPv6 etc.
            const mac = details.find(d => d.mac)?.mac || 'N/A';
            return {
                name,
                ip4: ipv4 ? `${ipv4.address}/${ipv4.netmask}` : 'N/A',
                mac: mac
            };
        }).filter(iface => iface.name !== 'lo');

        // 2. Check IP forwarding
        const ipForwarding = await fsPromises.readFile('/proc/sys/net/ipv4/ip_forward', 'utf-8');

        // 3. Check for our specific NAT rule
        const iptablesRules = await runSudo('iptables-save').catch(() => '');
        const natActive = iptablesRules.includes('-A POSTROUTING -m comment --comment "super-router-nat" -j MASQUERADE');
        
        // 4. Check dnsmasq status
        const dnsmasqStatus = await runSudo('systemctl is-active dnsmasq').catch(() => 'inactive');

        // 5. Try to read our saved config
        const configPath = path.join(__dirname, 'super-router.json');
        let savedConfig = {};
        try {
            const file = await fsPromises.readFile(configPath, 'utf-8');
            savedConfig = JSON.parse(file);
        } catch (e) { /* file doesn't exist, that's fine */ }

        res.json({
            ipForwarding: ipForwarding.trim() === '1',
            interfaces,
            natActive,
            dnsmasqActive: dnsmasqStatus.trim() === 'active',
            ...savedConfig
        });
    } catch (e) {
        res.status(500).json({ message: e.message });
    }
});

app.post('/api/host/apply-network-config', protect, async (req, res) => {
    const { wan, lan, lanIp } = req.body;
    if (!wan || !lan || !lanIp) {
        return res.status(400).json({ message: 'WAN interface, LAN interface, and LAN IP are required.' });
    }

    try {
        const lanIpParts = lanIp.split('/'); // e.g., '192.168.100.1/24'
        const lanAddress = lanIpParts[0];

        // 1. Configure interfaces
        await runSudo(`ip addr flush dev ${lan}`);
        await runSudo(`ip addr add ${lanIp} dev ${lan}`);
        await runSudo(`ip link set dev ${lan} up`);
        // We assume WAN is DHCP
        await runSudo(`dhclient -r ${wan}`).catch(e => console.warn(`Could not release DHCP on ${wan}: ${e.message}`));
        await runSudo(`dhclient ${wan}`).catch(e => console.warn(`Could not get DHCP on ${wan}: ${e.message}`));

        // 2. Enable IP Forwarding
        await runSudo('sysctl -w net.ipv4.ip_forward=1');

        // 3. Set up NAT
        await runSudo('iptables -t nat -F POSTROUTING'); // Flush old rules to prevent duplicates
        await runSudo(`iptables -t nat -A POSTROUTING -o ${wan} -j MASQUERADE -m comment --comment "super-router-nat"`);

        // 4. Configure and start dnsmasq for DHCP on LAN
        const lanSubnetStart = lanAddress.substring(0, lanAddress.lastIndexOf('.')) + '.100';
        const lanSubnetEnd = lanAddress.substring(0, lanAddress.lastIndexOf('.')) + '.200';
        const dnsmasqConf = `
interface=${lan}
dhcp-range=${lanSubnetStart},${lanSubnetEnd},12h
dhcp-option=option:router,${lanAddress}
dhcp-option=option:dns-server,8.8.8.8,1.1.1.1
log-dhcp
`;
        await fsPromises.writeFile('/tmp/dnsmasq.conf.super-router', dnsmasqConf);
        await runSudo(`mv /tmp/dnsmasq.conf.super-router /etc/dnsmasq.d/super-router.conf`);
        await runSudo('systemctl restart dnsmasq');
        
        // 5. Save config for status check
        const configPath = path.join(__dirname, 'super-router.json');
        const configToSave = { wanInterface: wan, lanInterface: lan, lanIp };
        await fsPromises.writeFile(configPath, JSON.stringify(configToSave, null, 2));

        res.json({ message: 'Router configuration applied successfully! Please test your network.' });
    } catch (e) {
        res.status(500).json({ message: `Failed to apply configuration: ${e.message}` });
    }
});

app.post('/api/host/revert-network-config', protect, async (req, res) => {
    try {
        const configPath = path.join(__dirname, 'super-router.json');
        let savedConfig = {};
        try {
            const file = await fsPromises.readFile(configPath, 'utf-8');
            savedConfig = JSON.parse(file);
        } catch (e) { 
            return res.status(404).json({ message: 'No saved configuration found to revert.' });
        }
        
        const { wanInterface, lanInterface } = savedConfig;
        
        await runSudo('systemctl stop dnsmasq').catch(e => console.warn(e.message));
        await runSudo('rm /etc/dnsmasq.d/super-router.conf').catch(e => console.warn(e.message));
        
        if (wanInterface) {
            await runSudo(`iptables -t nat -D POSTROUTING -o ${wanInterface} -j MASQUERADE -m comment --comment "super-router-nat"`).catch(e => console.warn(e.message));
        }

        await runSudo('sysctl -w net.ipv4.ip_forward=0');

        if (lanInterface) {
            await runSudo(`ip addr flush dev ${lanInterface}`).catch(e => console.warn(e.message));
            await runSudo(`dhclient ${lanInterface}`).catch(e => console.warn(`Could not get DHCP on ${lanInterface}: ${e.message}`));
        }

        await fsPromises.unlink(configPath);
        
        res.json({ message: 'Attempted to revert router configuration. You may need to reboot for settings to fully restore.' });

    } catch (e) {
        res.status(500).json({ message: `Failed to revert configuration: ${e.message}` });
    }
});

// --- AI Fixer ---
app.get('/api/fixer/file-content', protect, async (req, res) => {
    try {
        const content = await fs.promises.readFile(API_BACKEND_FILE, 'utf-8');
        res.type('text/plain').send(content);
    } catch (e) {
        res.status(500).send(e.message);
    }
});

app.post('/api/fixer/apply-fix', protect, (req, res) => {
    res.setHeader('Content-Type', 'text/event-stream');
    const send = (data) => res.write(`data: ${JSON.stringify(data)}\n\n`);
    
    const newCode = req.body;
    
    const apply = async () => {
        try {
            send({ log: 'Writing new code to api-backend/server.js...' });
            await fs.promises.writeFile(API_BACKEND_FILE, newCode, 'utf-8');
            send({ log: 'Restarting the API backend service with pm2...' });
            
            exec('pm2 restart mikrotik-api-backend', (err, stdout, stderr) => {
                if (err) {
                    send({ log: `PM2 restart failed: ${stderr}` });
                    send({ status: 'error', message: 'Failed to restart backend service.' });
                } else {
                    send({ log: 'Backend service restarted successfully.' });
                    send({ status: 'restarting' });
                }
                res.end();
            });

        } catch (e) {
            send({ status: 'error', message: e.message });
            res.end();
        }
    };
    apply();
});

// Report Generator
app.post('/api/generate-report', protect, async (req, res) => {
    try {
        const { view, routerName, geminiAnalysis } = req.body;
        const backendCode = await fs.promises.readFile(API_BACKEND_FILE, 'utf-8').catch(() => 'Could not read backend file.');
        
        let report = `--- MIKROTIK PANEL SYSTEM REPORT ---\n`;
        report += `Date: ${new Date().toISOString()}\n\n`;
        report += `--- AI DIAGNOSIS SUMMARY ---\n${geminiAnalysis}\n\n`;
        report += `--- CONTEXT ---\n`;
        report += `Current View: ${view}\n`;
        report += `Selected Router: ${routerName || 'None'}\n\n`;
        report += `--- BACKEND CODE (api-backend/server.js) ---\n\n${backendCode}\n`;
        
        res.setHeader('Content-disposition', 'attachment; filename=mikrotik-panel-report.txt');
        res.setHeader('Content-type', 'text/plain');
        res.charset = 'UTF-8';
        res.write(report);
        res.end();

    } catch (e) {
        res.status(500).json({ message: e.message });
    }
});


// --- Updater and Backups ---
const runCommandStream = (command, res, options = {}) => {
    return new Promise((resolve, reject) => {
        const child = exec(command, { cwd: path.join(__dirname, '..'), ...options });
        
        const stdoutChunks = [];
        const stderrChunks = [];

        child.stdout.on('data', data => {
            const log = data.toString();
            if (res) res.write(`data: ${JSON.stringify({ log })}\n\n`);
            stdoutChunks.push(log);
        });

        child.stderr.on('data', data => {
            const log = data.toString();
            const isError = !log.startsWith('Receiving objects:') && !log.startsWith('Resolving deltas:');
            if (res) res.write(`data: ${JSON.stringify({ log, isError })}\n\n`);
            stderrChunks.push(log);
        });

        child.on('close', code => {
            const stdout = stdoutChunks.join('').trim();
            const stderr = stderrChunks.join('').trim();
            if (code === 0) {
                resolve(stdout);
            } else {
                reject(new Error(stderr || `Command failed with exit code ${code}`));
            }
        });

        child.on('error', err => {
            reject(err);
        });
    });
};

const runCommand = (command) => runCommandStream(command, null);

app.get('/api/current-version', protect, async (req, res) => {
    try {
        // First, check if it's a git repo. This will throw if it's not.
        await runCommand("git rev-parse --is-inside-work-tree");
        
        // FIX: Use a null byte as a separator for robust parsing. This prevents crashes
        // when commit messages contain special characters like newlines.
        const stdout = await runCommand("git log -1 --pretty=format:'%h%x00%s%x00%b'");

        // The stdout from `git log` can be empty if there are no commits.
        if (!stdout.trim()) {
            return res.json({ 
                hash: 'N/A', 
                title: 'No Commits Found', 
                description: 'This repository does not have any commits yet.' 
            });
        }
        
        const parts = stdout.split('\0');
        const versionInfo = {
            hash: parts[0] || '',
            title: parts[1] || '',
            description: (parts[2] || '').trim(), // Trim trailing newlines from body
        };

        res.json(versionInfo);

    } catch (e) {
        let message = e.message;
        // Provide more user-friendly error messages
        if (message.includes('not a git repository')) {
            message = 'This is not a git repository. The updater requires the application to be cloned from git.';
        } else {
             message = 'Failed to parse version information from git. The repository might be in a strange state.';
        }
        res.status(500).json({ message });
    }
});

app.get('/api/update-status', protect, async (req, res) => {
    res.setHeader('Content-Type', 'text/event-stream');
    const send = (data) => res.write(`data: ${JSON.stringify(data)}\n\n`);

    try {
        send({ log: "Verifying git repository..." });
        await runCommand('git rev-parse --is-inside-work-tree');
        
        send({ log: "Connecting to remote repository..." });
        await runCommandStream('git fetch', res);
        send({ log: "Remote repository checked." });

        const [local, remote, mergeBase] = await Promise.all([
            runCommand('git rev-parse HEAD'),
            runCommand('git rev-parse @{u}'),
            runCommand('git merge-base HEAD @{u}')
        ]);
        
        if (local === remote) {
            send({ status: 'uptodate', message: 'Panel is up to date.' });
        } else if (local === mergeBase) {
            send({ status: 'available', message: 'New version available.' });
            const changelog = await runCommand("git log ..origin/main --pretty=format:'%h - %s (%cr)'");
            send({ newVersionInfo: {
                title: "New update found",
                description: "A new version of the panel is available.",
                changelog: changelog.trim()
            }});
        } else if (remote === mergeBase) {
            send({ status: 'ahead', message: 'Your version is ahead of the official repository.' });
        } else {
            send({ status: 'diverged', message: 'Your version has diverged. Manual update required.' });
        }

    } catch (e) {
        let message = e.message;
        if (message.includes('fatal: not a git repository')) {
            message = 'This is not a git repository. The updater requires the application to be cloned from git.';
        } else if (message.includes('Could not resolve host: github.com') || message.includes('fatal: unable to access')) {
            message = 'Failed to connect to GitHub. Please check your server\'s internet connection and DNS settings.';
        } else if (message.includes('fatal: no upstream configured')) {
            message = 'Git repository has no upstream branch configured. Unable to check for updates.';
        }
        send({ status: 'error', message });
    } finally {
        send({ status: 'finished' });
        res.end();
    }
});

app.get('/api/update-app', protect, async (req, res) => {
    res.setHeader('Content-Type', 'text/event-stream');
    const send = (data) => res.write(`data: ${JSON.stringify(data)}\n\n`);

    try {
        const backupFile = `backup-update-${new Date().toISOString().replace(/:/g, '-')}.tar.gz`;
        send({ log: `Creating application backup: ${backupFile}...` });
        
        const projectRoot = path.join(__dirname, '..');
        const archivePath = path.join(BACKUP_DIR, backupFile);
        
        await new Promise((resolve, reject) => {
            const output = fs.createWriteStream(archivePath);
            const archive = archiver('tar', { gzip: true });

            output.on('close', () => {
                send({ log: `Backup complete. Size: ${(archive.pointer() / 1024).toFixed(2)} KB` });
                resolve();
            });

            archive.on('warning', (err) => {
                send({ log: `Archive warning: ${err.message}`, isError: true });
            });

            archive.on('error', (err) => {
                reject(new Error(`Failed to create backup archive: ${err.message}`));
            });

            archive.pipe(output);
            archive.glob('**/*', {
                cwd: projectRoot,
                ignore: ['proxy/backups/**', '.git/**', '**/node_modules/**'],
                dot: true
            });
            archive.finalize();
        });
        
        send({ log: 'Pulling latest changes from git...' });
        await runCommandStream('git pull', res);
        
        send({ log: 'Installing dependencies for UI server...' });
        await runCommandStream('npm install --prefix proxy', res);

        send({ log: 'Installing dependencies for API backend...' });
        await runCommandStream('npm install --prefix api-backend', res);
        
        send({ log: 'Restarting panel services...' });
        exec('pm2 restart all', (err, stdout) => {
            if (err) {
                 send({ log: `PM2 restart failed: ${err.message}`, isError: true });
                 send({ status: 'error', message: err.message });
            } else {
                send({ log: stdout });
                send({ status: 'restarting' });
            }
            res.end();
        });

    } catch(e) {
        send({ log: e.message, isError: true });
        send({ status: 'error', message: e.message });
        res.end();
    }
});

app.get('/api/rollback-app', protect, (req, res) => {
    res.setHeader('Content-Type', 'text/event-stream');
    const send = (data) => res.write(`data: ${JSON.stringify(data)}\n\n`);
    const { backupFile } = req.query;
    if (!backupFile || backupFile.includes('..') || !backupFile.endsWith('.tar.gz')) {
        send({ status: 'error', message: 'Invalid application backup file specified.' });
        return res.end();
    }

    const rollback = async () => {
        try {
            send({ log: `Starting application rollback from ${backupFile}...`});
            const backupPath = path.join(BACKUP_DIR, backupFile);
            if (!fs.existsSync(backupPath)) {
                throw new Error('Backup file not found.');
            }
            
            send({ log: 'Extracting backup over current application files...'});
            const projectRoot = path.join(__dirname, '..');

            await tar.x({ // 'x' is for extract
                file: backupPath,
                cwd: projectRoot,
                onentry: (entry) => send({ log: `Restoring: ${entry.path}` })
            });
            send({ log: 'Extraction complete.' });

            send({ log: 'Re-installing dependencies for UI server...'});
            await runCommandStream('npm install --prefix proxy', res);

            send({ log: 'Re-installing dependencies for API backend...'});
            await runCommandStream('npm install --prefix api-backend', res);

            send({ log: 'Restarting panel services...'});
            exec('pm2 restart all', (err, stdout) => {
                 if (err) {
                     send({ log: `PM2 restart failed: ${err.message}`, isError: true });
                     send({ status: 'error', message: err.message });
                } else {
                    send({ log: stdout });
                    send({ status: 'restarting' });
                }
                res.end();
            });

        } catch (e) {
            send({ log: e.message, isError: true });
            send({ status: 'error', message: e.message });
            res.end();
        }
    };
    rollback();
});


// Database Backup/Restore
app.get('/api/create-backup', protect, async (req, res) => {
    const backupFile = `panel-db-backup-${new Date().toISOString().replace(/:/g, '-')}.sqlite`;
    try {
        await fs.promises.copyFile(DB_PATH, path.join(BACKUP_DIR, backupFile));
        res.json({ message: `Backup created successfully: ${backupFile}` });
    } catch(e) { res.status(500).json({ message: e.message }); }
});

app.get('/api/list-backups', protect, async (req, res) => {
    try {
        const dirents = await fs.promises.readdir(BACKUP_DIR, { withFileTypes: true });
        // Filter out directories and hidden files, then sort
        const files = dirents
            .filter(dirent => dirent.isFile() && !dirent.name.startsWith('.'))
            .map(dirent => dirent.name)
            .sort()
            .reverse();
        res.json(files);
    } catch (e) { res.status(500).json({ message: e.message }); }
});


app.post('/api/delete-backup', protect, async (req, res) => {
    try {
        const { backupFile } = req.body;
        // Basic path sanitization
        if (backupFile.includes('..')) return res.status(400).json({ message: 'Invalid filename' });
        await fs.promises.unlink(path.join(BACKUP_DIR, backupFile));
        res.json({ message: 'Backup deleted.' });
    } catch (e) { res.status(500).json({ message: e.message }); }
});

app.get('/download-backup/:filename', protect, (req, res) => {
    const { filename } = req.params;
    if (filename.includes('..')) return res.status(400).send('Invalid filename');
    res.download(path.join(BACKUP_DIR, filename));
});

app.get('/api/restore-backup', protect, (req, res) => {
    res.setHeader('Content-Type', 'text/event-stream');
    const send = (data) => res.write(`data: ${JSON.stringify(data)}\n\n`);

    const { backupFile } = req.query;
    if (!backupFile || backupFile.includes('..')) {
        send({ status: 'error', message: 'Invalid backup file specified.' });
        return res.end();
    }

    const restore = async () => {
        try {
            send({ log: 'Closing current database connection...'});
            if(db) await db.close();

            send({ log: `Restoring from ${backupFile}...`});
            await fs.promises.copyFile(path.join(BACKUP_DIR, backupFile), DB_PATH);

            send({ log: 'Restarting panel service...'});
            exec('pm2 restart mikrotik-manager', (err) => {
                if (err) send({ status: 'error', message: err.message });
                else send({ status: 'restarting' });
                res.end();
            });

        } catch (e) {
            send({ status: 'error', message: e.message });
            res.end();
        }
    };
    restore();
});


// --- Static file serving ---
app.use(express.static(path.join(__dirname, '..')));

// SPA Fallback:
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, '..', 'index.html'));
});

// --- Start Server ---
initDb().then(() => {
    app.listen(PORT, () => {
        console.log(`MikroTik Manager UI server running. Listening on http://localhost:${PORT}`);
    });
});